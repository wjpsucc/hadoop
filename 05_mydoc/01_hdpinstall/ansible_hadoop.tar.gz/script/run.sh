#!/bin/bash
hosts='/etc/ansible/hosts'

for (( i=1; i<=$3; i++ ))
do 
    if [ ${2} == "http" ]; then
	    docker run -d --privileged --rm --name ${2}${i} -h ${2}${i}-v ~/docker/http:/var/www/html $1 /sbin/init
    elif [ ${2} == "ansible" ]; then
        docker run -d --privileged --rm --name ${2}${i} -h ${2}${i} -v ~/docker/ansible-playbook:/ansible/playbooks $1 /sbin/init
    else
	    docker run -d --privileged --rm --name ${2}${i} -h ${2}${i} -v ~/docker/share_folder:/docker/share $1 /sbin/init
    fi
done
:<<\#
for (( i=1; i<=$3; i++ ))
do 
#	ip=`docker exec ${2}${i} ifconfig eth0 | grep "inet" | awk '{ print $3}'`
#	line=`grep ${ip} ${hosts}`
#	if [ -z "$line" ]; then
#		echo $ip >> ${hosts}
#	fi	
	docker cp ~/.ssh ${2}${i}:/root/
done
#
